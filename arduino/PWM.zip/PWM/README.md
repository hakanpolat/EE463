Based on:

https://code.google.com/archive/p/arduino-pwm-frequency-library/downloads

Modified version. PWM mode for timers 1, 3, 4, 5 changed from 8 to 14, to resolve phase/antiphase ambiguity.
Bug in const TimerData timer_to_pwm_data[] fixed.

Do not care about timer-2 at this time.

 Modified 10 June. 2017
 by 			Anatoly Kuzmenko
 					anatolyk69@gmail.com

